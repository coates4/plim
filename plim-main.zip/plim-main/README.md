# Gradient Canceling

Implementation of gradient canceling method. Here we provide examples codes for generating Table 2 (MNIST dataset). We first use the folder GradPC to generate target parameters using grad_attack.py, then use the folder GC to run Gradient Canceling for respective models.
